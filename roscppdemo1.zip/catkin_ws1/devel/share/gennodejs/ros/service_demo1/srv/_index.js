
"use strict";

let Greeting = require('./Greeting.js')

module.exports = {
  Greeting: Greeting,
};
