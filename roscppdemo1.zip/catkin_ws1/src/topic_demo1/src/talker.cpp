#include <ros/ros.h>
#include <topic_demo1/gps.h>

int main(int argc , char** argv)
{
    // 解析传入的ROS参数， 创建node第一步需要用到的函数解析传入的ROS参数， 
    ros::init(argc, argv, "talker"); // 解析参数，命名节点
    ros::NodeHandle nh; // 创建句柄，实例化node

    topic_demo1::gps msg; // 创建gps消息
    msg.x = 1.0; // msg内容
    msg.y = 1.0;
    msg.state = "working";

    // <topic_demo::gps>函数模板，里面放需要publisher的类型， 
    // topic名称为“gps_info”，队列长度1（消息在publish的时候先发到buff队列上）
    ros::Publisher pub = nh.advertise<topic_demo1::gps>("gps_info", 1); // 创建publisher
    ros::Rate loop_rate(1.0); // 定义循环发布频率，每秒发布一次消息1

    while(ros::ok()){ // 只要ros没有关一直循环
        msg.x = 1.03 * msg.x; // 指数增长
        msg.y = 1.01 * msg.y;
        ROS_INFO("Talker: GPS: x = %f, y = %f", msg.x, msg.y); // 输出当前msg 类似printf
        pub.publish(msg); // 发布消息
        loop_rate.sleep(); // 根据定义的频率发布，sleep

    }
    return 0;
    
}