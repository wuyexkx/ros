#include <ros/ros.h>
#include <topic_demo1/gps.h>
#include <std_msgs/Float32.h>

// ConstPtr在gps.h里定义，当.msg文件经过编译之后自动生成gps.h文件
// 在topic_demo::gps类里边定义了ConstPtr类型
void gpsCallback(const topic_demo1::gps::ConstPtr &msg)
{
    std_msgs::Float32 distance; // ros自带的数据类型,distance是结构体，只有一个成员data
    distance.data = sqrt(pow(msg->x,2) + pow(msg->y,2)); // 计算坐标到原点的距离
    ROS_INFO("Listener: Distance to origin = %f, state = %s ", distance.data, msg->state.c_str());
}


int main(int argc, char**argv)
{
    // 解析传入的ROS参数， 创建node第一步需要用到的函数解析传入的ROS参数， 创建node第一步需要用到的函数
    ros::init(argc, argv, "listener"); 
    ros::NodeHandle n;

    // 创建subscriber，订阅gps_info话题，
    // 消息队列, 回调函数(指针) ,接收到gps_info之后，需要处理的函数gpsCallback
    ros::Subscriber sub = n.subscribe("gps_info", 1, gpsCallback);
    // 处理队列里边的消息，有则调用回调函数，无则不调用
    ros::spin(); // 用当前可触发的回调函数，阻塞  // ros::spinonce 只查询一次
    return 0;

}