#include <ros/ros.h>
#include <service_demo1/Greeting.h>


bool handle_function(service_demo1::Greeting::Request& req, service_demo1::Greeting::Response &res)
{
    // 显示请求信息
    ROS_INFO("Request from %s with age %d", req.name.c_str(), req.age);
    // 处理请求，结果写入Response
    res.feedback = "Hi" + req.name + ", I'm server!";
    // 返回true，正确了处理请求
    return true; // 返回到请求的客户机上，客户机用client.call(srv)可以得到处理结果返回值
}


int main(int argc, char** argv)
{
    ros::init(argc, argv, "node_server");
    ros::NodeHandle nh;
    // 提供的服务叫greetings
    ros::ServiceServer service = nh.advertiseService("greetings", handle_function); 
    ros::spin();
    return 0;

}

