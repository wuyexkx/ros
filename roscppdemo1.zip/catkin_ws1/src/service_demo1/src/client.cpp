#include <ros/ros.h>
#include <service_demo1/Greeting.h>

int main(int argc, char** argv)
{
    ros::init(argc, argv, "node_client");
    ros::NodeHandle nh;
    ros::ServiceClient client = nh.serviceClient<service_demo1::Greeting>("greetings");

    service_demo1::Greeting srv;
    srv.request.name = "HAN";
    srv.request.age = 20;

    // 判断请求是否处理成功，服务端回调函数返回值
    if(client.call(srv))
    {
        ROS_INFO("Feedback from server: %s.", srv.response.feedback.c_str());
    }
    else
    {
        ROS_ERROR("Failed to call service greetings.");
        return 1;
    }

    return 0;
}