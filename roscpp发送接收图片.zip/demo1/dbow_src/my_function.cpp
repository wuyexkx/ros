#include <iostream>
#include <vector>

#include "my_function.h"
#include <fstream>
using namespace DBoW3;
using namespace std;


void getFileNames(string path,vector<string>& filenames)
{
    DIR *pDir;
    struct dirent* ptr;
    if(!(pDir = opendir(path.c_str())))
        return; // 如果路径打开，不存在
    while((ptr = readdir(pDir))!=0) {
        string image_name(ptr->d_name);
        if (strcmp(ptr->d_name, ".") != 0 && strcmp(ptr->d_name, "..") != 0)  
            // 只保留.jpg路径
            if (image_name.substr(image_name.size() - 4) == ".jpg")
                filenames.push_back(path + "/" + ptr->d_name);
    }
    closedir(pDir);
}

void loadTxt(string filename, vector<string>& names)
{
    ifstream infile(filename.c_str());
    if (!infile){cerr<<"ERROR::: Failed to open the file <" <<filename << ">" << endl;exit(0);}
    string one_row;
    while(infile >> one_row)
    {
        names.push_back(one_row);
    }
    infile.close(); // 关闭文件

    // for(int i = 0; i < names.size()/50; i++)  cout << "read txt content: " << names[i] << endl;
}

cv::Mat load_Features(cv::Mat image, int size_scale, float split) throw (std::exception){
    //select detector
    cv::Ptr<cv::Feature2D> fdetector;
    fdetector=cv::ORB::create();

    vector<cv::KeyPoint> keypoints;
    cv::Mat feature;

    // ------------------预处理图片：resize split---------------------------
    // 速度排序： INTER_NEAREST 默认双线性插值，INTER_CUBIC
    image = image(cv::Range(0, int(image.rows*split)), cv::Range::all());
    resize(image, image,cv::Size(image.cols/size_scale, image.rows/size_scale), 0, 0);
    // -------------------------------------------------------------------

    fdetector->detectAndCompute(image, cv::Mat(), keypoints, feature);
    // cout<<"done detecting features" << endl;
    return feature;
}
