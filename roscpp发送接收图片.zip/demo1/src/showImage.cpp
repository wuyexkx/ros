#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include "my_function.h"
#include <vector>
#include <iostream>
#include <string>

using namespace DBoW3;
using namespace std;




void imageCallback(const sensor_msgs::ImageConstPtr& msg, vector<string>& names, Database * db, 
                    cv::Mat *grayImage, cv::Mat *features, cv::Mat *image)
{
    
    QueryResults ret;

    try
    {
     
        *image = cv_bridge::toCvShare(msg, "bgr8")->image;
        cv::cvtColor(*image, *grayImage, CV_BGR2GRAY);
        if((*image).empty())throw std::runtime_error("Read the image is empty!");
        *features = load_Features(*image);
        (*db).query(*features, ret, 1);
        string maxvlupath = names[ret[0].Id];
        string result = maxvlupath.substr(maxvlupath.rfind("/")+1, 
        (maxvlupath.rfind("-")-(maxvlupath.rfind("/")+1)));

        ROS_INFO(result.c_str());
    }    
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("Could not convert from %s to 'bgr8'.", msg->encoding.c_str());
    }
}


int main(int argc, char** argv)
{
    ros::init(argc, argv, "node_showImage");
    ros::NodeHandle nh;

// ========================================================================
    vector<string> names;
    loadTxt("/home/xkx/roscv_ws/devel/lib/demo1/mould_names.txt", names);
    Database db("/home/xkx/roscv_ws/devel/lib/demo1/small_db.yml.gz");
    cv::Mat grayImage;
    cv::Mat features;
    cv::Mat image;

// ========================================================================

    image_transport::ImageTransport it(nh);
    image_transport::Subscriber sub = it.subscribe("topic_images", 1, 
                    boost::bind(imageCallback, _1, names, &db, &grayImage, &features, &image));
    ros::spin();

}

