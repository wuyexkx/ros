#!/usr/bin/env python
#-*-coding:utf-8-*-

import rospy
# *包含了Greeting  GreetingRespose  GreetingRequest
from service_demo2.srv import *


def handle_function(req):
    rospy.loginfo("Request from " + req.name + " with age " + str(req.age))
    return GreetingResponse("Hi %s. I'm server!"%req.name)

def server():
    rospy.init_node("node_server")
    s = rospy.Service("greetings", Greeting, handle_function)
    rospy.loginfo("Ready to handle the request:")
    rospy.spin()


if __name__ == "__main__":
    server()

