#!/usr/bin/env python
#-*-coding:utf-8-*-

import rospy
# *包含了Greeting  GreetingRespose  GreetingRequest
from service_demo2.srv import *


def client_srv():
    rospy.init_node("node_client")
    # 阻塞等待服务端出现“greetings”的srv
    rospy.wait_for_service("greetings")
    try:
        # 创建客户端，请求"greetings"srv，请求类型Greeting
        client = rospy.ServiceProxy("greetings", Greeting)
        rosp = client("HAN", 20) # 等价于 client.call("HAN", 20)
        rospy.loginfo("Message from server: %s", rosp.feedback)

    except rospy.ServiceException, e:
        rospy.logwarn("Service call failed: %s", e)


if __name__ == "__main__":
    client_srv()
