#!/usr/bin/env python  
#-*-coding:utf-8-*-

# 让编译器找python的解释器
import rospy
from topic_demo2.msg import gps # 导入自定义数据类型


def talker():
    # queue_size表示消息丢失前的最大序列长度，
    # queue_size = 0表示buffer无线长，容易耗尽内存，
    # queue_size = 1~10适用于只取最新值的情况，
    # queue_size>10适用于需要记录这些值的情况。
    pub = rospy.Publisher("gps_info", gps, queue_size=10)
    rospy.init_node("pytalker", anonymous=True)
    rate = rospy.Rate(1)
    x = 1.0
    y = 2.0
    state = "working"

    while not rospy.is_shutdown():
        rospy.loginfo("Talker GPS: x=%f, y=%f", x, y)
        # 构造gps临时对象
        pub.publish(gps( x ,y, state))
        x = x * 1.03
        y = y * 1.01
        rate.sleep()


if __name__ == "__main__":
    talker()



