
"use strict";

let gps = require('./gps.js');

module.exports = {
  gps: gps,
};
